/**
 * Contains interface to communicate with web app
 */
package abstraction;
