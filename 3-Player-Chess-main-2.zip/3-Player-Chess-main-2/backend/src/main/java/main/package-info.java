/**
 * Main Class where complete 3 Player chess logic is written
 */
package main;
