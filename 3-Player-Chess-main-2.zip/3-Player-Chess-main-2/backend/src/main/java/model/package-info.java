/**
 * Contains board logic and the pieces logic
 */
package model;
