/**
 * Contains helper classes for the backend logic
 * Logging
 * Movement of pieces
 * BoardAdapter to communicate with web app
 */
package utility;
