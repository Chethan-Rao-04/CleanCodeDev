/**
 * Contains helper classes for the backend logic
 * Enum classes for Colour, Direction and Position
 * Custom exceptions
 */
package common;
