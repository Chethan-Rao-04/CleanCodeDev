/**
 * Contains the main function entry point to the springboot application
 */
package application;
