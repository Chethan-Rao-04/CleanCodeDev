/**
 * Controller has interfaces to communicate with backend
 */
package application.controller;
